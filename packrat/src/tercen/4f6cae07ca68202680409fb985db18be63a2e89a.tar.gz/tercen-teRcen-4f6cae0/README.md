# Tercen R client

## Install teRcen package

```R
install.packages('devtools')
devtools::install_github("tercen/teRcen", ref = "0.7.0")
```